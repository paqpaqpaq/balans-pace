#include "esphome/core/log.h"

#include "pace_bms_select_implementation.h"

namespace esphome {
namespace pace_bms_base {

static const char* const TAG = "pace_bms_base.select_impl";

void PaceBmsSelectImplementation::control(const std::string& text) {
	if(readonly_ == true)
		return;

	uint8_t value = value_from_option(text);

	this->control_callback_.call(text, value);

	// required for the UX not to get out of sync
	this->publish_state(text);
}

uint8_t PaceBmsSelectImplementation::value_from_option(std::string text)
{
	const auto &options = this->traits.get_options();
	auto opt_it = std::find(options.begin(), options.end(), text);
	if (opt_it == options.end()) {
		ESP_LOGD(TAG, "%s: unable to find value for option '%s'", this->name_.c_str(), text.c_str());
		return 0xFF;
	}
	size_t idx = std::distance(options.begin(), opt_it);
	uint8_t value = this->values_[idx];

	ESP_LOGD(TAG, "%s: found value 0x%02X for option '%s'", this->name_.c_str(), value, text.c_str());

	return value;
}

std::string PaceBmsSelectImplementation::option_from_value(uint8_t value) {
	const auto &options = this->traits.get_options();
	auto opt_it = std::find(this->values_.begin(), this->values_.end(), value);
	if (opt_it == this->values_.end()) {
		ESP_LOGD(TAG, "%s: unable to find option for value 0x%02X", this->name_.c_str(), value);
		return std::string("error");
	}
	size_t idx = std::distance(this->values_.begin(), opt_it);
	std::string text = std::string(options[idx]);

	ESP_LOGD(TAG, "%s: found option '%s' for value 0x%02X", this->name_.c_str(), text.c_str(), value);

	return text;
}

}  // namespace pace_bms_base
}  // namespace esphome
