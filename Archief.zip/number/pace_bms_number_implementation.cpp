#include "esphome/core/log.h"

#include "pace_bms_number_implementation.h"

namespace esphome {
namespace pace_bms_base {

static const char* const TAG = "pace_bms_base.number_impl";

void PaceBmsNumberImplementation::control(float number) {
	ESP_LOGD(TAG, "control: new value %f", number);

	// callbacks
	this->control_callbacks_.call(number);

	// required for the UX not to get out of sync
	this->publish_state(number);
}

}  // namespace pace_bms_base
}  // namespace esphome
